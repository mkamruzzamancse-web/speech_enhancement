#!/usr/bin/env python
"""One-factor-at-a-time ablation of ESN hyper-parameters on the VALIDATION split."""
import argparse, os, json
import numpy as np
from sereservoir import data, experiment as ex
from sereservoir.esn import FrameESN

GRID = {"spectral_radius": [0.5, 0.8, 0.9, 0.99],
        "leak": [0.1, 0.3, 0.5, 1.0],
        "n_res": [250, 500, 1000, 2000],
        "ridge": [1e-4, 1e-2, 1.0]}
BASE = {"spectral_radius": 0.9, "leak": 0.5, "n_res": 1000, "ridge": 1e-2}

ap = argparse.ArgumentParser()
ap.add_argument("--clean_dir", required=True); ap.add_argument("--noise_dir", required=True)
ap.add_argument("--out", default="runs/ablation"); ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--snrs", type=float, nargs="+", default=[0, 5, 10])
ap.add_argument("--context", type=int, default=2); ap.add_argument("--n_val_files", type=int, default=10)
ap.add_argument("--seeds", type=int, default=3, help="reservoir seeds per setting")
a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)

split = data.split_clean_files(a.clean_dir, a.seed)
tr = data.build_pairs(split["train"], data.load_noises(a.noise_dir, "train"), a.snrs, "random", 2, seed=a.seed)
va = data.build_pairs(split["val"][:a.n_val_files], data.load_noises(a.noise_dir, "val"), a.snrs, "grid", seed=a.seed + 2)
ex.featurize(tr, a.context); ex.featurize(va, a.context)
nx, ny = ex.fit_normalizers(tr); train_xy = ex.make_xy(tr, nx, ny, a.context)
n_in, n_out = train_xy[0][0].shape[1], train_xy[0][1].shape[1]

results = []
for factor, values in GRID.items():
    for v in values:
        cfg = {**BASE, factor: v}
        scores = []
        for s in range(a.seeds):
            esn = FrameESN(n_in, n_out, seed=s, **cfg).fit(train_xy)
            rows = ex.evaluate(va, {"esn": ex.Enhancer(esn, nx, ny, a.context)})
            scores.append(np.mean([r["si_sdr"] for r in rows]))
        results.append({"factor": factor, "value": v, "si_sdr_mean": float(np.mean(scores)),
                        "si_sdr_std": float(np.std(scores))})
        print(results[-1])
json.dump(results, open(os.path.join(a.out, "ablation.json"), "w"), indent=2)
