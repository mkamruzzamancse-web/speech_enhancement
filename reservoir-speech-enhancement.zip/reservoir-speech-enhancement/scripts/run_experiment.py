#!/usr/bin/env python
"""Train ESN (+ optional GRU) and evaluate against classical baselines on held-out data."""
import argparse, json, os, pickle, time
import numpy as np
from sereservoir import data, experiment as ex
from sereservoir.baselines import spectral_subtraction, wiener
from sereservoir.esn import FrameESN


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clean_dir", required=True)
    ap.add_argument("--noise_dir", required=True)
    ap.add_argument("--out", default="runs/exp1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--snrs", type=float, nargs="+", default=[0, 5, 10])
    ap.add_argument("--train_mixes_per_file", type=int, default=2)
    ap.add_argument("--n_test_files", type=int, default=20)
    ap.add_argument("--context", type=int, default=2, help="frames of context on each side")
    # ESN
    ap.add_argument("--n_res", type=int, default=1000)
    ap.add_argument("--spectral_radius", type=float, default=0.9)
    ap.add_argument("--leak", type=float, default=0.5)
    ap.add_argument("--input_scale", type=float, default=0.5)
    ap.add_argument("--ridge", type=float, default=1e-2)
    # GRU
    ap.add_argument("--gru", action="store_true", help="also train the GRU baseline (needs torch)")
    ap.add_argument("--gru_epochs", type=int, default=20)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    json.dump(vars(a), open(os.path.join(a.out, "config.json"), "w"), indent=2)

    split = data.split_clean_files(a.clean_dir, a.seed)
    print({k: len(v) for k, v in split.items()}, "files per split")
    tr = data.build_pairs(split["train"], data.load_noises(a.noise_dir, "train"), a.snrs,
                          "random", a.train_mixes_per_file, seed=a.seed)
    te = data.build_pairs(split["test"][:a.n_test_files], data.load_noises(a.noise_dir, "test"),
                          a.snrs, "grid", seed=a.seed + 1)
    ex.featurize(tr, a.context); ex.featurize(te, a.context)
    nx, ny = ex.fit_normalizers(tr)
    train_xy = ex.make_xy(tr, nx, ny, a.context)
    n_in, n_out = train_xy[0][0].shape[1], train_xy[0][1].shape[1]

    t0 = time.time()
    esn = FrameESN(n_in, n_out, n_res=a.n_res, spectral_radius=a.spectral_radius, leak=a.leak,
                   input_scale=a.input_scale, ridge=a.ridge, seed=a.seed).fit(train_xy)
    print(f"ESN trained in {time.time() - t0:.1f}s")
    methods = {"noisy": None,
               "spectral_sub": lambda p: spectral_subtraction(p["noisy"]),
               "wiener": lambda p: wiener(p["noisy"]),
               "esn": ex.Enhancer(esn, nx, ny, a.context)}
    pickle.dump({"esn": esn, "nx": nx, "ny": ny}, open(os.path.join(a.out, "esn.pkl"), "wb"))

    if a.gru:
        from sereservoir.gru import GRUBaseline
        t0 = time.time()
        gru = GRUBaseline(n_in, n_out, epochs=a.gru_epochs, seed=a.seed).fit(train_xy)
        print(f"GRU trained in {time.time() - t0:.1f}s")
        methods["gru"] = ex.Enhancer(gru, nx, ny, a.context)

    rows = ex.evaluate(te, methods, os.path.join(a.out, "results.csv"))
    table = ex.summarize(rows)
    open(os.path.join(a.out, "results.md"), "w").write(table)
    print(table)


if __name__ == "__main__":
    main()
