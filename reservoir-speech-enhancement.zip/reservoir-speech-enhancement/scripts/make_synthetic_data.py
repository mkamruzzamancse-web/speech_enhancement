#!/usr/bin/env python
"""Generate SYNTHETIC 'speech-like' signals + noise for smoke-testing the pipeline only.
These are NOT speech. Do not report results obtained on them."""
import argparse, os
import numpy as np, soundfile as sf

SR = 16000
ap = argparse.ArgumentParser()
ap.add_argument("--out", default="data_synth"); ap.add_argument("--speakers", type=int, default=8)
ap.add_argument("--files", type=int, default=4); ap.add_argument("--seconds", type=float, default=3.0)
a = ap.parse_args(); rng = np.random.default_rng(0)


def fake_speech(f0, n):
    t = np.arange(n) / SR
    f = f0 * (1 + 0.15 * np.sin(2 * np.pi * rng.uniform(0.5, 2) * t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = sum(np.sin(h * ph) / h for h in range(1, 12))
    env = np.clip(np.sin(2 * np.pi * rng.uniform(2, 4) * t) + 0.3, 0, None)
    return 0.3 * x * env


def colored(n, power):
    X = np.fft.rfft(rng.standard_normal(n))
    f = np.maximum(np.fft.rfftfreq(n), 1.0 / n)
    return np.fft.irfft(X / f ** (power / 2), n)


n = int(a.seconds * SR)
for s in range(a.speakers):
    d = os.path.join(a.out, "clean", f"spk{s:02d}"); os.makedirs(d, exist_ok=True)
    f0 = rng.uniform(90, 250)
    for i in range(a.files):
        sf.write(os.path.join(d, f"u{i}.wav"), fake_speech(f0, n), SR)
nd = os.path.join(a.out, "noise"); os.makedirs(nd, exist_ok=True)
L = 60 * SR
sf.write(os.path.join(nd, "white.wav"), 0.1 * rng.standard_normal(L), SR)
p = colored(L, 1.0); sf.write(os.path.join(nd, "pink.wav"), 0.1 * p / p.std(), SR)
b = sum(np.roll(fake_speech(rng.uniform(90, 250), L), rng.integers(L)) for _ in range(6))
sf.write(os.path.join(nd, "babble.wav"), 0.1 * b / b.std(), SR)
print("wrote", a.out)
