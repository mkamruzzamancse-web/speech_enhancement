"""GRU baseline with the same input/output representation as the ESN.
Requires torch (imported lazily so the rest of the package works without it)."""
from __future__ import annotations
import numpy as np


class GRUBaseline:
    def __init__(self, n_in, n_out, hidden=256, layers=2, epochs=20, lr=2e-3,
                 batch=8, crop=200, seed=0, device=None):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed)
        self.torch, self.n_in, self.n_out = torch, n_in, n_out
        self.epochs, self.lr, self.batch, self.crop = epochs, lr, batch, crop
        self.rng = np.random.default_rng(seed)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        class Net(nn.Module):
            def __init__(s):
                super().__init__()
                s.gru = nn.GRU(n_in, hidden, layers, batch_first=True)
                s.out = nn.Linear(hidden, n_out)

            def forward(s, x):
                h, _ = s.gru(x)
                return s.out(h)

        self.net = Net().to(self.device)

    def fit(self, pairs):
        torch = self.torch
        pairs = list(pairs)
        opt = torch.optim.Adam(self.net.parameters(), lr=self.lr)
        for ep in range(self.epochs):
            self.net.train()
            order = self.rng.permutation(len(pairs))
            total = 0.0
            for i in range(0, len(order), self.batch):
                chunk = [pairs[j] for j in order[i:i + self.batch]]
                L = min(self.crop, min(len(u) for u, _ in chunk))
                xs, ys = [], []
                for u, y in chunk:
                    s = self.rng.integers(0, len(u) - L + 1)
                    xs.append(u[s:s + L]); ys.append(y[s:s + L])
                x = torch.tensor(np.stack(xs), dtype=torch.float32, device=self.device)
                y = torch.tensor(np.stack(ys), dtype=torch.float32, device=self.device)
                loss = torch.nn.functional.l1_loss(self.net(x), y)
                opt.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
                opt.step()
                total += loss.item() * len(chunk)
            print(f"[GRU] epoch {ep + 1}/{self.epochs}  train L1 = {total / len(pairs):.4f}")
        return self

    def predict(self, U):
        torch = self.torch
        self.net.eval()
        with torch.no_grad():
            x = torch.tensor(U[None], dtype=torch.float32, device=self.device)
            return self.net(x)[0].cpu().numpy()
