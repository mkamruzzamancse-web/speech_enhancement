"""Data loading, speaker-disjoint splits, and noise mixing at controlled SNR.

Expected layout:
  clean_dir/<speaker_id>/*.wav     (or flat *.wav -> split by file, with a warning)
  noise_dir/white.wav pink.wav babble.wav ...   (file stem = noise type)

Leakage control:
  * speakers are split train/val/test (no speaker appears in two splits)
  * each noise file is cut into disjoint time portions: first 70% train,
    next 15% val, last 15% test
"""
from __future__ import annotations
import glob, os, warnings
from math import gcd
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

SR = 16000
SPLITS = {"train": (0.0, 0.70), "val": (0.70, 0.85), "test": (0.85, 1.0)}


def load_wav(path: str) -> np.ndarray:
    x, sr = sf.read(path, dtype="float64", always_2d=False)
    if x.ndim > 1:
        x = x.mean(1)
    if sr != SR:
        g = gcd(sr, SR)
        x = resample_poly(x, SR // g, sr // g)
    return x


def split_clean_files(clean_dir: str, seed: int = 0, frac=(0.7, 0.15, 0.15)):
    files = sorted(glob.glob(os.path.join(clean_dir, "**", "*.wav"), recursive=True))
    if not files:
        raise FileNotFoundError(f"no .wav files under {clean_dir}")
    groups = {}
    for f in files:
        groups.setdefault(os.path.basename(os.path.dirname(f)), []).append(f)
    rng = np.random.default_rng(seed)
    if len(groups) < 3:
        warnings.warn("fewer than 3 speaker folders found: splitting by FILE (speakers may leak "
                      "across splits). Put files in one folder per speaker for a valid evaluation.")
        order = rng.permutation(len(files))
        units = [[files[i]] for i in order]
    else:
        keys = sorted(groups)
        rng.shuffle(keys)
        units = [groups[k] for k in keys]
    n = len(units)
    a, b = int(frac[0] * n), int((frac[0] + frac[1]) * n)
    a, b = max(a, 1), max(b, a + 1)
    flat = lambda us: [f for u in us for f in u]
    return {"train": flat(units[:a]), "val": flat(units[a:b]), "test": flat(units[b:])}


def load_noises(noise_dir: str, split: str) -> dict:
    lo, hi = SPLITS[split]
    out = {}
    for p in sorted(glob.glob(os.path.join(noise_dir, "*.wav"))):
        x = load_wav(p)
        out[os.path.splitext(os.path.basename(p))[0]] = x[int(lo * len(x)):int(hi * len(x))]
    if not out:
        raise FileNotFoundError(f"no noise .wav files in {noise_dir}")
    return out


def mix(clean: np.ndarray, noise: np.ndarray, snr_db: float, rng) -> tuple:
    """Return (noisy, clean) scaled together so peak(noisy) <= 0.95."""
    if len(noise) < len(clean):
        noise = np.tile(noise, int(np.ceil(len(clean) / len(noise))))
    s = rng.integers(0, len(noise) - len(clean) + 1)
    n = noise[s:s + len(clean)]
    p_s, p_n = np.mean(clean ** 2) + 1e-12, np.mean(n ** 2) + 1e-12
    n = n * np.sqrt(p_s / (p_n * 10 ** (snr_db / 10)))
    noisy = clean + n
    g = 0.95 / (np.max(np.abs(noisy)) + 1e-9)
    return noisy * g, clean * g


def build_pairs(files, noises, snrs, mode="random", per_file=1, seg_seconds=4.0, seed=0):
    """mode='random': per_file random (noise, snr) draws per clean file (training).
       mode='grid'  : every noise x every snr per clean file (evaluation)."""
    rng = np.random.default_rng(seed)
    L = int(seg_seconds * SR)
    pairs = []
    for f in files:
        x = load_wav(f)
        if len(x) < SR:                     # skip clips shorter than 1 s
            continue
        if len(x) > L:
            s = rng.integers(0, len(x) - L + 1)
            x = x[s:s + L]
        combos = ([(k, s_) for k in noises for s_ in snrs] if mode == "grid" else
                  [(list(noises)[rng.integers(len(noises))], float(rng.choice(snrs)))
                   for _ in range(per_file)])
        for k, snr in combos:
            noisy, clean = mix(x, noises[k], snr, rng)
            pairs.append({"noisy": noisy, "clean": clean, "noise": k, "snr": float(snr),
                          "id": os.path.basename(f)})
    return pairs
