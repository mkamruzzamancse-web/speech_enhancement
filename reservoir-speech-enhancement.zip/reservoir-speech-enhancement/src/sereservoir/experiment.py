"""Shared pipeline: pairs -> features -> train models -> enhance -> metrics."""
from __future__ import annotations
import csv, os
import numpy as np
from . import features as ft
from .esn import FrameESN
from .baselines import spectral_subtraction, wiener
from .metrics import all_metrics


def featurize(pairs, context):
    for p in pairs:
        p["Zn"] = ft.stft(p["noisy"])
        p["Xn"] = ft.log_mag(p["Zn"])
        p["Yc"] = ft.log_mag(ft.stft(p["clean"]))
    return pairs


def fit_normalizers(train_pairs):
    nx = ft.Normalizer().fit([p["Xn"] for p in train_pairs])
    ny = ft.Normalizer().fit([p["Yc"] for p in train_pairs])
    return nx, ny


def make_xy(pairs, nx, ny, context):
    return [(ft.stack_context(nx(p["Xn"]), context), ny(p["Yc"])) for p in pairs]


class Enhancer:
    """Wraps a model (ESN or GRU) with normalisation + reconstruction."""
    def __init__(self, model, nx, ny, context):
        self.model, self.nx, self.ny, self.context = model, nx, ny, context

    def __call__(self, p):
        U = ft.stack_context(self.nx(p["Xn"]), self.context)
        pred = self.ny.inverse(self.model.predict(U))
        return ft.reconstruct(p["Zn"], pred, len(p["noisy"]))


def evaluate(pairs, methods: dict, out_csv: str | None = None):
    """methods: name -> callable(pair) -> waveform. Returns list of row dicts."""
    rows = []
    for p in pairs:
        for name, fn in methods.items():
            est = p["noisy"] if name == "noisy" else fn(p)
            m = all_metrics(est, p["clean"])
            rows.append({"method": name, "noise": p["noise"], "snr": p["snr"], "id": p["id"], **m})
    if out_csv:
        os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
        with open(out_csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader(); w.writerows(rows)
    return rows


def summarize(rows) -> str:
    """Markdown table: mean +- std over test utterances, per method x noise x snr."""
    import collections
    g = collections.defaultdict(list)
    for r in rows:
        g[(r["noise"], r["snr"], r["method"])].append(r)
    lines = ["| noise | SNR (dB) | method | SI-SDR (dB) | STOI | PESQ-WB |", "|---|---|---|---|---|---|"]
    for (noise, snr, method) in sorted(g, key=lambda k: (k[0], k[1], k[2] != "noisy", k[2])):
        rs = g[(noise, snr, method)]
        f = lambda key: (np.nanmean([r[key] for r in rs]), np.nanstd([r[key] for r in rs]))
        (a, sa), (b, sb), (c, sc) = f("si_sdr"), f("stoi"), f("pesq")
        lines.append(f"| {noise} | {snr:g} | {method} | {a:.2f} ± {sa:.2f} | {b:.3f} ± {sb:.3f} | {c:.2f} ± {sc:.2f} |")
    return "\n".join(lines)
