"""Reservoir-computing speech enhancement."""
__version__ = "0.1.0"
