"""Metrics computed on TIME-DOMAIN waveforms at 16 kHz (never on spectrogram vectors)."""
from __future__ import annotations
import numpy as np

SR = 16000


def si_sdr(est: np.ndarray, ref: np.ndarray, eps=1e-12) -> float:
    est = est - est.mean(); ref = ref - ref.mean()
    alpha = (est @ ref) / (ref @ ref + eps)
    target = alpha * ref
    return float(10 * np.log10((target @ target + eps) / (((est - target) ** 2).sum() + eps)))


def stoi(est, ref) -> float:
    from pystoi import stoi as _stoi
    return float(_stoi(ref, est, SR, extended=False))


def pesq_wb(est, ref) -> float:
    try:
        from pesq import pesq
        return float(pesq(SR, ref, est, "wb"))
    except Exception:       # missing package or too-short / silent signal
        return float("nan")


def all_metrics(est, ref) -> dict:
    return {"si_sdr": si_sdr(est, ref), "stoi": stoi(est, ref), "pesq": pesq_wb(est, ref)}
