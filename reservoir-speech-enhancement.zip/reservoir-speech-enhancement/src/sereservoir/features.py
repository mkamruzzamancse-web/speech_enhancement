"""STFT features. Frames are the *time axis* that the reservoir runs over."""
from __future__ import annotations
import numpy as np
import scipy.signal as sps

SR = 16000
N_FFT = 512      # 32 ms
HOP = 128        # 8 ms
EPS = 1e-5


def stft(x: np.ndarray) -> np.ndarray:
    """Complex STFT, shape (n_freq, n_frames)."""
    _, _, Z = sps.stft(x, fs=SR, window="hann", nperseg=N_FFT,
                       noverlap=N_FFT - HOP, boundary="zeros", padded=True)
    return Z


def istft(Z: np.ndarray, length: int) -> np.ndarray:
    _, x = sps.istft(Z, fs=SR, window="hann", nperseg=N_FFT,
                     noverlap=N_FFT - HOP, boundary=True)
    if len(x) < length:
        x = np.pad(x, (0, length - len(x)))
    return x[:length]


def log_mag(Z: np.ndarray) -> np.ndarray:
    """Log-magnitude, shape (n_frames, n_freq) -- time first."""
    return np.log(np.abs(Z) + EPS).T


def stack_context(F: np.ndarray, k: int) -> np.ndarray:
    """Concatenate frames t-k..t+k (edge padded). k=0 returns F unchanged.
    Lets a causal reservoir see a small look-ahead window."""
    if k == 0:
        return F
    P = np.pad(F, ((k, k), (0, 0)), mode="edge")
    T = F.shape[0]
    return np.concatenate([P[i:i + T] for i in range(2 * k + 1)], axis=1)


class Normalizer:
    """Per-bin mean/std fitted on TRAINING data only."""
    def fit(self, arrays):
        A = np.concatenate(arrays, axis=0)
        self.mean = A.mean(0)
        self.std = A.std(0) + 1e-6
        return self

    def __call__(self, F):
        return (F - self.mean) / self.std

    def inverse(self, F):
        return F * self.std + self.mean


def reconstruct(noisy_Z: np.ndarray, pred_logmag: np.ndarray, length: int) -> np.ndarray:
    """Predicted log-magnitude (T,F) + noisy phase -> waveform.
    Magnitude is capped at the noisy magnitude (i.e. an implicit mask <= 1)."""
    mag = np.exp(pred_logmag).T - EPS
    mag = np.clip(mag, 0.0, np.abs(noisy_Z))
    Z = mag * np.exp(1j * np.angle(noisy_Z))
    return istft(Z, length)
