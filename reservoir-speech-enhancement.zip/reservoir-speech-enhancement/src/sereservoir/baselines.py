"""Classical, training-free baselines operating on the complex STFT."""
from __future__ import annotations
import numpy as np
from .features import stft, istft


def _noise_psd(Y: np.ndarray) -> np.ndarray:
    """Noise PSD per bin from the 10th percentile of the periodogram over time.
    Bias-corrected for a chi-square(2) periodogram (10th percentile ~ 0.105 * mean).
    Simple and robust, but assumes noise is roughly stationary."""
    return np.percentile(np.abs(Y) ** 2, 10, axis=1, keepdims=True) / 0.105


def spectral_subtraction(noisy: np.ndarray, alpha=2.0, floor=0.05) -> np.ndarray:
    Y = stft(noisy)
    N = _noise_psd(Y)
    P = np.abs(Y) ** 2
    mag2 = np.maximum(P - alpha * N, floor * P)
    return istft(np.sqrt(mag2 / np.maximum(P, 1e-12)) * Y, len(noisy))


def wiener(noisy: np.ndarray, smooth=0.9, g_min=0.1) -> np.ndarray:
    Y = stft(noisy)
    N = _noise_psd(Y)
    P = np.abs(Y) ** 2
    xi = np.maximum(P / N - 1.0, 0.0)           # ML a-priori SNR
    for t in range(1, xi.shape[1]):             # recursive smoothing over time
        xi[:, t] = smooth * xi[:, t - 1] + (1 - smooth) * xi[:, t]
    G = np.maximum(xi / (1.0 + xi), g_min)
    return istft(G * Y, len(noisy))
