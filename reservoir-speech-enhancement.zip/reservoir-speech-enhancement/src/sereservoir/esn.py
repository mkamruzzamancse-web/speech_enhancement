"""Frame-wise Echo State Network for spectral mapping.

State update (leaky ESN), run over the STFT frames u_t of ONE utterance:

    x_t = (1 - a) x_{t-1} + a * tanh(W_in u_t + W x_{t-1})

Readout (closed-form ridge regression, no back-propagation):

    y_t = W_out [x_t ; u_t ; 1],
    W_out = argmin ||Y - F W||^2 + lambda ||W||^2 ,  F = [X U 1]

W is sparse, rescaled so its spectral radius equals `spectral_radius`
(a commonly used heuristic for the echo state property when < 1).
The state is reset to zero at the start of every utterance.
"""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigs


class FrameESN:
    def __init__(self, n_in, n_out, n_res=1000, spectral_radius=0.9, density=0.02,
                 input_scale=0.5, leak=0.5, ridge=1e-2, washout=5, seed=0):
        self.n_in, self.n_out, self.n_res = n_in, n_out, n_res
        self.sr, self.leak, self.ridge, self.washout = spectral_radius, leak, ridge, washout
        rng = np.random.default_rng(seed)
        W = sp.random(n_res, n_res, density=density, format="csr", random_state=rng,
                      data_rvs=lambda n: rng.uniform(-1, 1, n))
        self.W = (W * (spectral_radius / self._rho(W))).tocsr()
        self.W_in = rng.uniform(-1, 1, (n_res, n_in)) * input_scale
        self.W_out = None

    @staticmethod
    def _rho(W):
        n = W.shape[0]
        if n <= 64:
            rho = np.max(np.abs(np.linalg.eigvals(W.toarray())))
        else:
            rho = np.abs(eigs(W, k=1, which="LM", return_eigenvectors=False)[0])
        return rho if rho > 0 else 1.0

    def states(self, U: np.ndarray) -> np.ndarray:
        """U: (T, n_in) -> reservoir states (T, n_res)."""
        T = U.shape[0]
        drive = U @ self.W_in.T            # (T, n_res), precomputed
        x = np.zeros(self.n_res)
        S = np.empty((T, self.n_res))
        a = self.leak
        for t in range(T):
            x = (1 - a) * x + a * np.tanh(drive[t] + self.W @ x)
            S[t] = x
        return S

    def _features(self, U):
        S = self.states(U)
        return np.concatenate([S, U, np.ones((len(U), 1))], axis=1)

    def fit(self, pairs):
        """pairs: iterable of (U, Y) with U (T, n_in), Y (T, n_out).
        Accumulates normal equations so memory does not grow with data size."""
        d = self.n_res + self.n_in + 1
        A = np.zeros((d, d))
        B = np.zeros((d, self.n_out))
        for U, Y in pairs:
            F = self._features(U)[self.washout:]
            A += F.T @ F
            B += F.T @ Y[self.washout:]
        A[np.diag_indices(d)] += self.ridge
        self.W_out = np.linalg.solve(A, B)
        return self

    def predict(self, U):
        return self._features(U) @ self.W_out
