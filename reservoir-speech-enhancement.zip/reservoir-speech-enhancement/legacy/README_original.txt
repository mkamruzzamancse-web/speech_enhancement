This folder contains: 
--- Report ---
1. Pdf file of the report
2. docx file of the report

--- Codes (ipynb) ---
1. RNN_white_final
2. RNN_pink_final
3. RNN_babble_final
4. LSM_white_final
5. LSM_pink_final
6. LSM_babble_final

--- Figures --- 
Figure 1 - 8