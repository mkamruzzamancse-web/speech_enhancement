import numpy as np
from sereservoir import features as ft, data, experiment as ex
from sereservoir.esn import FrameESN
from sereservoir.metrics import si_sdr


def test_stft_roundtrip():
    x = np.random.default_rng(0).standard_normal(16000)
    y = ft.istft(ft.stft(x), len(x))
    assert si_sdr(y, x) > 60


def test_spectral_radius_is_enforced():
    esn = FrameESN(10, 5, n_res=100, spectral_radius=0.9, seed=1)
    rho = np.max(np.abs(np.linalg.eigvals(esn.W.toarray())))
    assert abs(rho - 0.9) < 1e-6


def test_mix_hits_target_snr():
    rng = np.random.default_rng(0)
    clean = rng.standard_normal(16000); noise = rng.standard_normal(32000)
    noisy, c = data.mix(clean, noise, 5.0, rng)
    n = noisy - c
    snr = 10 * np.log10(np.mean(c ** 2) / np.mean(n ** 2))
    assert abs(snr - 5.0) < 1e-6


def test_esn_fits_and_predicts_shapes():
    rng = np.random.default_rng(0)
    pairs = [(rng.standard_normal((50, 8)), rng.standard_normal((50, 4))) for _ in range(3)]
    esn = FrameESN(8, 4, n_res=40, seed=0).fit(pairs)
    assert esn.predict(pairs[0][0]).shape == (50, 4)


def test_esn_state_resets_per_utterance():
    rng = np.random.default_rng(0)
    esn = FrameESN(8, 4, n_res=40, seed=0)
    U = rng.standard_normal((30, 8))
    assert np.allclose(esn.states(U), esn.states(U))  # no hidden carry-over between calls
